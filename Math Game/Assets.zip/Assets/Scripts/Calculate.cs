using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Calculate : MonoBehaviour
{
    int PrimeNum, SecondNum, ValueNum, RequestFinal;
    public Text FirstNumber, SecondNumber, Symbol, Result;
    private string VarSymbol;
    public GameObject Canvas;
    //public Camera homeScreenCamera;
    //public Camera additionScreenCamera;

    // Start is called before the first frame update
    void Start()
    {
        Canvas.SetActive(false);
        GameObject.Find("Main Camera").transform.position = new Vector3(-1.62f, 1.55f, -4.295f);
       // homeScreenCamera.enabled = true;
        //additionScreenCamera.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        

        if (Input.GetKeyDown("a")) //Addition
        {
            Canvas.SetActive(true);
            calculateFn("Add");
            //HomeScreenView();          
        }

        if (Input.GetKeyDown("s")) //Subtraction
        {
            Canvas.SetActive(true);
            calculateFn("Subtract");           
        }

        if (Input.GetKeyDown("m")) //Multiplication
        {
            Canvas.SetActive(true);
            calculateFn("Multiply");           
        }

        if (Input.GetKeyDown("d")) //Division
        {
            Canvas.SetActive(true);
            calculateFn("Divide");
        }

    }

    /*public void HomeScreenView()
    {
        homeScreenCamera.enabled = true;
        additionScreenCamera.enabled = false;
    }*/

    public void FunctionForAddition()
    {
        Canvas.SetActive(true);
        Debug.Log(" Function Addition");
    }

    public void FunctionForSubtraction()
    {
        Canvas.SetActive(true);
        Debug.Log(" Function Subtraction");
    }

    public void FunctionForMultiplication()
    {
        Canvas.SetActive(true);
        Debug.Log(" Function Multiplication");
    }

    public void FunctionForDivision()
    {
        Canvas.SetActive(true);
        Debug.Log(" Function Division");
    }

    public void calculateFn(string operation)
    {
        PrimeNum = Random.Range(1, 10);
        SecondNum = Random.Range(1, 10);

        if (PrimeNum - SecondNum < 0)
        {
            ValueNum = SecondNum;
            SecondNum = PrimeNum;
            PrimeNum = ValueNum;
        }

        if (operation=="Add")
        {
            RequestFinal = PrimeNum + SecondNum;
            VarSymbol = "Add";
        }

        if (operation == "Subtract")
        {
            RequestFinal = PrimeNum - SecondNum;
            VarSymbol = "Subtract";
        }

        if (operation == "Multiply")
        {
            RequestFinal = PrimeNum * SecondNum;
            VarSymbol = "Multiply";
        }

        if (operation == "Divide")
        {
            RequestFinal = PrimeNum/SecondNum;
            VarSymbol = "Divide";
        }

        FirstNumber.text = PrimeNum.ToString();
        SecondNumber.text = SecondNum.ToString();
        Result.text = RequestFinal.ToString();

        if (VarSymbol == "Add") { Symbol.text = "+"; }
        if (VarSymbol == "Subtract") { Symbol.text = "-"; }
        if (VarSymbol == "Multiply") { Symbol.text = "*"; }
        if (VarSymbol == "Divide") { Symbol.text = "/"; }



    }
    /*public void ReturnMenu()
    {
        Canvas.SetActive(false);
        GameObject.Find("Main Camera").transform.position = new Vector3(-1.62f, 1.55f, -4.295f);

    }*/
   
}
