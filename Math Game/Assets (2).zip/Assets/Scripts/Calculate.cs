using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using EasyUI.Dialogs;

public class Calculate : MonoBehaviour
{
    int PrimeNum, SecondNum, ValueNum, RequestFinal, RandomNumber, RandomNum, RandomNum2, Temporary;
    public Text FirstNumber, SecondNumber, Symbol, Result, Answer1, Answer2, Answer3;
    private string VarSymbol;
    public GameObject Canvas;


    // Start is called before the first frame update
    void Start()
    {
        Canvas.SetActive(false);
        GameObject.Find("Main Camera").transform.position = new Vector3(-1.62f, 1.55f, -4.295f);
        DialogUI.Instance.SetTitle("Hint").SetMessage("Please help, tim is abusing me").Hide();
        
    }

    // Update is called once per frame
    
    public void FunctionForAddition()
    {
        Canvas.SetActive(true);
        calculateFn("Add");
        Debug.Log(" Function Addition");
        
    }

    public void FunctionForSubtraction()
    {
        Canvas.SetActive(true);
        calculateFn("Subtract");
        Debug.Log(" Function Subtraction");
    }

    public void FunctionForMultiplication()
    {
        Canvas.SetActive(true);
        calculateFn("Multiply");
        Debug.Log(" Function Multiplication");
    }

    public void FunctionForDivision()
    {
        Canvas.SetActive(true);
        calculateFn("Divide");
        Debug.Log(" Function Division");
    }

    public void calculateFn(string operation)
    {
        PrimeNum = Random.Range(1, 10);
        SecondNum = Random.Range(1, 10);
        RandomNum = Random.Range(1, 25);
        RandomNum2 = Random.Range(1, 25);

        if (PrimeNum - SecondNum < 0)
        {
            ValueNum = SecondNum;
            SecondNum = PrimeNum;
            PrimeNum = ValueNum;
        }

        if (operation == "Add")
        {
            RequestFinal = PrimeNum + SecondNum;
            VarSymbol = "Add";
        }

        if (operation == "Subtract")
        {
            RequestFinal = PrimeNum - SecondNum;
            VarSymbol = "Subtract";
        }

        if (operation == "Multiply")
        {
            RequestFinal = PrimeNum * SecondNum;
            VarSymbol = "Multiply";
        }

        if (operation == "Divide")
        {
            RequestFinal = PrimeNum / SecondNum;
            VarSymbol = "Divide";
        }

        if (RandomNum - RandomNum2 < 0)
        {
            RandomNumber = RandomNum;
            RandomNum = RandomNum2;
            RandomNum2 = RandomNumber;
        }

        FirstNumber.text = PrimeNum.ToString();
        SecondNumber.text = SecondNum.ToString();
        /*Answer1.text = RandomNum.ToString();
        Answer2.text = RandomNum2.ToString();
        Answer3.text = RequestFinal.ToString();*/


        if (VarSymbol == "Add") { Symbol.text = "+"; }
        if (VarSymbol == "Subtract") { Symbol.text = "-"; }
        if (VarSymbol == "Multiply") { Symbol.text = "x"; }
        if (VarSymbol == "Divide") { Symbol.text = "/"; }

        Temporary = Random.Range(1, 6);
        if(Temporary == 1)
        {
            Answer1.text = RequestFinal.ToString(); Answer2.text = RandomNum.ToString(); Answer3.text = RandomNum2.ToString();
        }
        if (Temporary == 2)
        {
            Answer1.text = RequestFinal.ToString(); Answer2.text = RandomNum2.ToString(); Answer3.text = RandomNum.ToString();
        }
        if (Temporary == 3)
        {
            Answer1.text = RandomNum.ToString(); Answer2.text = RequestFinal.ToString(); Answer3.text = RandomNum2.ToString();
        }
        if (Temporary == 4)
        {
            Answer1.text = RandomNum.ToString(); Answer2.text = RandomNum2.ToString(); Answer3.text = RequestFinal.ToString();
        }
        if (Temporary == 5)
        {
            Answer1.text = RandomNum2.ToString(); Answer2.text = RequestFinal.ToString(); Answer3.text = RandomNum.ToString();
        }
        if (Temporary == 6)
        {
            Answer1.text = RandomNum2.ToString(); Answer2.text = RandomNum.ToString(); Answer3.text = RequestFinal.ToString();
        }

    }
    public void ReturnMenu()
    {
        Canvas.SetActive(false);
        GameObject.Find("Main Camera").transform.position = new Vector3(-1.62f, 1.55f, -4.295f);

    }
    public void Answer_1()
    {
        if(Answer1.text == RequestFinal.ToString())
        {
            Debug.Log("Correct");
        }
        else
        {
            Debug.Log("Incorrect");
            Debug.Log("Idiot");
        }
    }
    public void Answer_2()
    {
        if (Answer2.text == RequestFinal.ToString())
        {
            Debug.Log("Correct");
        }
        else
        {
            Debug.Log("Incorrect");
            Debug.Log("Yummy");
        }
    }
    public void Answer_3()
    {
        if (Answer3.text == RequestFinal.ToString())
        {
            Debug.Log("Correct");
        }
        else
        {
            Debug.Log("Incorrect");
            Debug.Log("Tim likes men");
        }
    }


}
