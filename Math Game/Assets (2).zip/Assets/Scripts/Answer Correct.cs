using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnswerCorrect : MonoBehaviour
{
    private void onMouseDown()
    {
        Debug.Log("Correct");
    }
}
